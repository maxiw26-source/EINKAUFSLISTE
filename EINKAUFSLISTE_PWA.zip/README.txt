EINKAUFSLISTE PWA

Alle Dateien und den Ordner "static" in dein GitHub-Repository hochladen.

Wichtig:
- Vorhandene Dateien ersetzen.
- Der Ordner static muss inklusive aller Dateien hochgeladen werden.
- Render startet danach automatisch einen neuen Deploy.
- Start Command: gunicorn app:app

iPhone:
Safari öffnen -> Teilen -> Zum Home-Bildschirm.

Android:
In der App erscheint ein Installationsknopf oder im Browser-Menü "App installieren".
